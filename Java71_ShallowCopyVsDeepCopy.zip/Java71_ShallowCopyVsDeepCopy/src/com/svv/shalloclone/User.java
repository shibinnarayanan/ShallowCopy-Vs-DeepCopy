package com.svv.shalloclone;

public class User implements Cloneable {

	public int id;
	public String name;
	public Address address;

	public User() {
	}

	public User(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + "]";
	}

	// shallow clone
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		return super.clone();
	}

}
