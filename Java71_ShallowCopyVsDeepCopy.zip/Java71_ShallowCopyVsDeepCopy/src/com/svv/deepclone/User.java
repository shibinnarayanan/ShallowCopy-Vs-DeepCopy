package com.svv.deepclone;

public class User implements Cloneable {

	public int id;
	public String name;
	public Address address;

	public User() {
	}

	public User(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + "]";
	}

	// deep clone
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		User user = (User) super.clone();
		user.address = (Address) this.address.clone();
		return user;
	}

}
