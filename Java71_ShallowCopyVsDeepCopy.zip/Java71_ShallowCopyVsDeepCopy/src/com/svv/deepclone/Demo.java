package com.svv.deepclone;

public class Demo {

	public static void main(String[] args) {

		Address addr = new Address("Kochi", "Kerala");
		User usr = new User(1, "Shibin", addr);
		User usrCopy1 = null;

		try {
			usrCopy1 = (User) usr.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Original and Clone object before changing reference object address\n");
		System.out.println("Original object" + usr);
		System.out.println("Clone object" + usrCopy1);

		usrCopy1.id = 101;
		usrCopy1.name = "Shibin V V";
		usrCopy1.address.city = "Palakkad";

		System.out.println("\nOriginal and Clone object after changing reference object address\n");
		System.out.println("Original object" + usr);
		System.out.println("Clone object " + usrCopy1);

	}

}
